import type {Metadata} from 'next';
import {Playfair_Display, Plus_Jakarta_Sans} from 'next/font/google';
import './globals.css';

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-serif',
  display: 'swap',
});

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'SKB Family Restaurant | Angara, Ranchi',
  description:
    'Visit SKB Family Restaurant in Angara, Ranchi, Jharkhand. Discover a welcoming family dining experience and contact us at 09798832616.',
  openGraph: {
    title: 'SKB Family Restaurant | Angara, Ranchi',
    description:
      'Visit SKB Family Restaurant in Angara, Ranchi, Jharkhand. Discover a welcoming family dining experience and contact us at 09798832616.',
    type: 'website',
    locale: 'en_IN',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'SKB Family Restaurant | Angara, Ranchi',
    description:
      'Visit SKB Family Restaurant in Angara, Ranchi, Jharkhand. Discover a welcoming family dining experience and contact us at 09798832616.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`scroll-smooth ${playfair.variable} ${jakarta.variable}`}>
      <body className="font-sans antialiased bg-[#121110] text-[#f7f5f0] selection:bg-[#e09843] selection:text-[#1c140e]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
