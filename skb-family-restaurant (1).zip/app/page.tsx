import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import About from '@/components/About';
import WhyChooseUs from '@/components/WhyChooseUs';
import MenuSection from '@/components/MenuSection';
import GallerySection from '@/components/GallerySection';
import ReviewsSection from '@/components/ReviewsSection';
import FaqSection from '@/components/FaqSection';
import LocationContact from '@/components/LocationContact';
import CtaBanner from '@/components/CtaBanner';
import Footer from '@/components/Footer';
import MobileStickyBar from '@/components/MobileStickyBar';

export default function HomePage() {
  const phone = '09798832616';
  const mapsUrl =
    'https://www.google.com/maps/search/?api=1&query=SKB+Family+Restaurant,+Angara,+Ranchi,+Jharkhand';

  return (
    <div className="min-h-screen bg-[#121110] text-[#f7f5f0] flex flex-col antialiased selection:bg-amber-600 selection:text-white">
      {/* 1. Sticky Navigation */}
      <Navbar phone={phone} />

      <main className="flex-1 pb-16 sm:pb-0">
        {/* 2. Hero Section */}
        <Hero phone={phone} mapsUrl={mapsUrl} />

        {/* 3. About Section */}
        <About />

        {/* 4. Why Choose Us */}
        <WhyChooseUs />

        {/* 5. Menu Section */}
        <MenuSection phone={phone} />

        {/* 6. Gallery Section */}
        <GallerySection />

        {/* 7. Reviews Section */}
        <ReviewsSection mapsUrl={mapsUrl} />

        {/* 8. Frequently Asked Questions (FAQ) Section */}
        <FaqSection phone={phone} />

        {/* 9. Location & Contact Section */}
        <LocationContact phone={phone} mapsUrl={mapsUrl} />

        {/* 10. Call to Action Banner */}
        <CtaBanner phone={phone} mapsUrl={mapsUrl} />
      </main>

      {/* 11. Footer */}
      <Footer phone={phone} mapsUrl={mapsUrl} />

      {/* Mobile Sticky Quick Action Bar */}
      <MobileStickyBar phone={phone} mapsUrl={mapsUrl} />
    </div>
  );
}
