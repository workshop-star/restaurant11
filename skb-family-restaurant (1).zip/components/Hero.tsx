'use client';

import Image from 'next/image';
import { Phone, MapPin, Star, Navigation, Clock, ShieldCheck, Heart } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroProps {
  phone: string;
  mapsUrl: string;
}

export default function Hero({ phone, mapsUrl }: HeroProps) {
  return (
    <section
      id="hero"
      className="relative min-h-[92vh] lg:min-h-screen flex items-center justify-center overflow-hidden pt-24 pb-16 lg:py-28"
    >
      {/* Background Photography with Warm Dark Atmosphere */}
      <div className="absolute inset-0 z-0">
        <Image
          src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=2000&q=85"
          alt="SKB Family Restaurant warm dining atmosphere"
          fill
          priority
          sizes="100vw"
          className="object-cover object-center scale-105 animate-[pulse_10s_ease-in-out_infinite]"
          referrerPolicy="no-referrer"
        />
        {/* Layered Gradient Overlays for High Contrast and Warmth */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#121110] via-[#121110]/80 to-[#121110]/60" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#121110]/90 via-[#121110]/60 to-[#121110]/80" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#121110_100%)] opacity-80" />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Rating Badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="inline-flex items-center gap-2.5 px-4 py-2 rounded-full bg-black/60 backdrop-blur-md border border-amber-500/40 text-amber-200 text-xs sm:text-sm font-medium shadow-xl shadow-black/40 mb-6"
          id="hero-rating-badge"
        >
          <div className="flex items-center text-amber-400 gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            ))}
          </div>
          <span className="font-semibold text-white">4.5 / 5</span>
          <span className="text-stone-400">•</span>
          <span className="text-amber-100 font-medium">46 Customer Reviews</span>
        </motion.div>

        {/* Restaurant Name */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1, ease: 'easeOut' }}
          id="hero-main-heading"
          className="font-serif text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-[#fffaf0] mb-5 drop-shadow-sm"
        >
          SKB Family Restaurant
        </motion.h1>

        {/* Main Tagline */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2, ease: 'easeOut' }}
          id="hero-tagline"
          className="text-xl sm:text-2xl md:text-3xl font-serif italic text-amber-200/90 mb-4 max-w-2xl mx-auto tracking-wide"
        >
          &ldquo;Good Food. Great Taste. Happy Moments.&rdquo;
        </motion.p>

        {/* Location Subtitle */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3, ease: 'easeOut' }}
          className="flex items-center justify-center gap-2 text-stone-300 text-sm sm:text-base mb-10"
          id="hero-location-text"
        >
          <MapPin className="w-4 h-4 text-amber-400 flex-shrink-0" />
          <span>Angara, Ranchi, Jharkhand</span>
        </motion.div>

        {/* Two Primary CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.4, ease: 'easeOut' }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-5 mb-14"
        >
          {/* Call Now Button */}
          <a
            href={`tel:${phone}`}
            id="hero-call-now-btn"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-gradient-to-r from-amber-600 via-amber-500 to-amber-600 hover:from-amber-500 hover:to-amber-500 text-white font-semibold text-base sm:text-lg shadow-xl shadow-amber-950/60 hover:shadow-amber-600/40 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 border border-amber-300/40"
          >
            <Phone className="w-5 h-5 text-amber-100" />
            <span>Call Now ({phone})</span>
          </a>

          {/* Get Directions Button */}
          <a
            href={mapsUrl}
            target="_blank"
            rel="noopener noreferrer"
            id="hero-directions-btn"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-[#201c18]/80 hover:bg-[#2c2621] text-[#f7f3eb] font-semibold text-base sm:text-lg border border-stone-600/50 hover:border-amber-400/60 backdrop-blur-md shadow-lg shadow-black/40 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200"
          >
            <Navigation className="w-5 h-5 text-amber-400" />
            <span>Get Directions</span>
          </a>
        </motion.div>

        {/* Feature Pills / Badges */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-2xl mx-auto pt-6 border-t border-white/10"
        >
          <div className="flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-white/[0.04] border border-white/5 text-stone-300 text-xs sm:text-sm">
            <Heart className="w-4 h-4 text-amber-400" />
            <span>Family-Friendly Dining</span>
          </div>
          <div className="flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-white/[0.04] border border-white/5 text-stone-300 text-xs sm:text-sm">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <span>Quality & Freshness</span>
          </div>
          <div className="flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-white/[0.04] border border-white/5 text-stone-300 text-xs sm:text-sm">
            <Clock className="w-4 h-4 text-amber-400" />
            <span>Comfortable Atmosphere</span>
          </div>
        </motion.div>
      </div>

      {/* Decorative Wave Divider at Bottom */}
      <div className="absolute bottom-0 left-0 right-0 h-12 bg-gradient-to-t from-[#151311] to-transparent pointer-events-none" />
    </section>
  );
}
