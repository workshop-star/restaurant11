'use client';

import { Phone, Navigation, Heart, UtensilsCrossed } from 'lucide-react';
import { motion } from 'motion/react';

interface CtaBannerProps {
  phone: string;
  mapsUrl: string;
}

export default function CtaBanner({ phone, mapsUrl }: CtaBannerProps) {
  return (
    <motion.section
      initial={{ opacity: 0, y: 35 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15, margin: '0px 0px -50px 0px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="py-16 sm:py-24 bg-[#151311] relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, scale: 0.97, y: 15 }}
          whileInView={{ opacity: 1, scale: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#2a1e14] via-[#211710] to-[#2a1e14] border border-amber-500/30 p-8 sm:p-14 lg:p-16 text-center shadow-2xl shadow-black/80"
        >
          {/* Subtle background glow */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 max-w-2xl mx-auto space-y-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-semibold tracking-wider uppercase">
              <Heart className="w-3.5 h-3.5 text-amber-400" />
              Family & Group Dining
            </div>

            <h2
              id="cta-banner-heading"
              className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight"
            >
              Planning Your Next Meal?
            </h2>

            <p className="text-stone-300 text-base sm:text-lg leading-relaxed">
              Visit SKB Family Restaurant and enjoy a great dining experience with your family and
              friends in Angara, Ranchi.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
              <a
                href={`tel:${phone}`}
                id="cta-banner-call-btn"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-8 py-4 rounded-full bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-semibold text-base shadow-xl shadow-amber-950/70 hover:shadow-amber-600/30 transition-all duration-200 active:scale-95 border border-amber-400/40"
              >
                <Phone className="w-5 h-5 text-amber-100" />
                <span>Call Now ({phone})</span>
              </a>

              <a
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                id="cta-banner-directions-btn"
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-4 rounded-full bg-stone-900/80 hover:bg-stone-800 text-stone-200 font-medium text-base border border-stone-700 hover:border-amber-400/50 transition-all duration-200 active:scale-95"
              >
                <Navigation className="w-4 h-4 text-amber-400" />
                <span>Get Directions</span>
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </motion.section>
  );
}
