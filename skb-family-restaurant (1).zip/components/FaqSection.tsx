'use client';

import { useState } from 'react';
import { HelpCircle, ChevronDown, Car, Users, Utensils, Phone, Clock, ShieldCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface FaqSectionProps {
  phone: string;
}

interface FaqItem {
  id: string;
  question: string;
  answer: string;
  icon: typeof Car;
  tag: string;
}

export default function FaqSection({ phone }: FaqSectionProps) {
  const [openId, setOpenId] = useState<string | null>('faq-parties');

  const faqs: FaqItem[] = [
    {
      id: 'faq-parking',
      question: 'Is parking available at SKB Family Restaurant?',
      answer:
        'Yes, convenient parking space is available for guests arriving by personal car, two-wheeler, or private vehicle at our location in Angara, Ranchi.',
      icon: Car,
      tag: 'Parking & Arrival',
    },
    {
      id: 'faq-dietary',
      question: 'Do you cater to vegetarian and non-vegetarian dietary preferences?',
      answer:
        'Yes, we accommodate both vegetarian and non-vegetarian diners. Our kitchen prepares flavorful, fresh options to suit diverse family tastes. If you have specific preferences or spice requirements, please inform our team upon arrival.',
      icon: Utensils,
      tag: 'Dietary Options',
    },
    {
      id: 'faq-parties',
      question: 'Can we book tables or plan for large family parties and celebrations?',
      answer: `Yes, we gladly welcome group dining, family birthdays, anniversaries, and casual get-togethers. For parties of 6 or more guests, we recommend calling us directly at ${phone} in advance so our staff can prepare comfortable seating arrangements for your group.`,
      icon: Users,
      tag: 'Group Bookings',
    },
    {
      id: 'faq-timings',
      question: 'What are the recommended dining hours to visit?',
      answer: `We serve guests for lunch, afternoon meals, and evening family dinners in Angara. For quick confirmation on today's service schedule or special occasion visits, feel free to call our team directly at ${phone}.`,
      icon: Clock,
      tag: 'Visiting Hours',
    },
    {
      id: 'faq-atmosphere',
      question: 'Is the restaurant suitable for children and senior family members?',
      answer:
        'Absolutely. SKB Family Restaurant is purposefully designed with relaxed seating and respectful hospitality, ensuring children, parents, and grandparents all enjoy a calm, hospitable, and hygienic dining experience.',
      icon: ShieldCheck,
      tag: 'Family Comfort',
    },
    {
      id: 'faq-inquiry',
      question: 'How can I place an advance inquiry or confirm directions?',
      answer: `You can reach our team immediately by phone at ${phone} or connect via WhatsApp for quick questions, special table requests, or turn-by-turn driving guidance in Angara, Ranchi.`,
      icon: Phone,
      tag: 'Quick Assistance',
    },
  ];

  const toggleFaq = (id: string) => {
    setOpenId((prev) => (prev === id ? null : id));
  };

  return (
    <motion.section
      id="faq"
      initial={{ opacity: 0, y: 35 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15, margin: '0px 0px -50px 0px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="py-20 lg:py-28 bg-[#121110] relative overflow-hidden"
    >
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-14"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold tracking-wider uppercase mb-3">
            <HelpCircle className="w-3.5 h-3.5" />
            Common Questions
          </div>
          <h2
            id="faq-heading"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fffdfa] tracking-tight"
          >
            Frequently Asked Questions
          </h2>
          <p className="mt-4 text-stone-300 text-sm sm:text-base max-w-xl mx-auto">
            Helpful information regarding dining, group reservations, parking, and services at SKB Family Restaurant in Angara, Ranchi.
          </p>
        </motion.div>

        {/* FAQ Accordion List */}
        <div className="space-y-4 max-w-4xl mx-auto">
          {faqs.map((faq, index) => {
            const isOpen = openId === faq.id;
            const Icon = faq.icon;

            return (
              <motion.div
                key={faq.id}
                id={faq.id}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.05 }}
                className={`rounded-2xl transition-all duration-300 border overflow-hidden ${
                  isOpen
                    ? 'bg-gradient-to-r from-[#221c17] to-[#181412] border-amber-500/40 shadow-lg shadow-black/60'
                    : 'bg-[#181513] border-stone-800/80 hover:border-stone-700 hover:bg-[#1d1916]'
                }`}
              >
                <button
                  type="button"
                  id={`btn-${faq.id}`}
                  onClick={() => toggleFaq(faq.id)}
                  aria-expanded={isOpen}
                  aria-controls={`content-${faq.id}`}
                  className="w-full text-left p-5 sm:p-6 flex items-center justify-between gap-4 cursor-pointer"
                >
                  <div className="flex items-center gap-4">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors ${
                        isOpen
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-stone-900 text-stone-400 border border-stone-800'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[11px] font-medium text-amber-400/90 block mb-0.5">
                        {faq.tag}
                      </span>
                      <h3 className="font-serif text-base sm:text-lg font-bold text-stone-100">
                        {faq.question}
                      </h3>
                    </div>
                  </div>

                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 border transition-all duration-300 ${
                      isOpen
                        ? 'bg-amber-500 text-stone-950 border-amber-400 rotate-180'
                        : 'bg-stone-900 text-stone-400 border-stone-800'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={`content-${faq.id}`}
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                    >
                      <div className="px-5 sm:px-6 pb-6 pt-1 text-stone-300 text-sm sm:text-base leading-relaxed border-t border-stone-800/60 ml-0 sm:ml-14">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom Help Prompt */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-12 text-center p-6 rounded-2xl bg-gradient-to-r from-amber-950/20 via-stone-900/40 to-amber-950/20 border border-amber-500/20 max-w-2xl mx-auto"
        >
          <p className="text-stone-300 text-sm mb-3">
            Have a specific question not covered here or planning a special party?
          </p>
          <a
            href={`tel:${phone}`}
            id="faq-call-help-btn"
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-full bg-amber-600 hover:bg-amber-500 text-white text-xs sm:text-sm font-semibold shadow-md transition-colors"
          >
            <Phone className="w-3.5 h-3.5" />
            <span>Call Us at {phone}</span>
          </a>
        </motion.div>
      </div>
    </motion.section>
  );
}
