'use client';

import { Users, UtensilsCrossed, Sparkles, Armchair, ShieldCheck } from 'lucide-react';
import { motion } from 'motion/react';

export default function WhyChooseUs() {
  const features = [
    {
      id: 'why-family-friendly',
      title: 'Family Friendly',
      description:
        'A warm and welcoming dining setting where guests of all ages, from children to elders, feel relaxed and well accommodated.',
      icon: Users,
      badge: 'Gatherings & Groups',
    },
    {
      id: 'why-great-taste',
      title: 'Great Taste',
      description:
        'Appetizing, flavorful preparations prepared with care so that every dish delivers a memorable and satisfying culinary experience.',
      icon: UtensilsCrossed,
      badge: 'Satisfying Flavors',
    },
    {
      id: 'why-quality-experience',
      title: 'Quality Experience',
      description:
        'Polite hospitality, a neat and hygienic environment, and attentive care to ensure your visit to SKB Family Restaurant is delightful.',
      icon: Sparkles,
      badge: 'Attentive Care',
    },
    {
      id: 'why-comfortable-dining',
      title: 'Comfortable Dining',
      description:
        'Spacious, relaxed seating designed for leisurely meals, pleasant conversations, and unwinding with close family and companions.',
      icon: Armchair,
      badge: 'Relaxed Ambience',
    },
  ];

  return (
    <motion.section
      id="why-us"
      initial={{ opacity: 0, y: 35 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15, margin: '0px 0px -50px 0px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="py-20 bg-[#121110] relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold tracking-wider uppercase mb-3">
            <ShieldCheck className="w-3.5 h-3.5" />
            Our Core Pillars
          </div>
          <h2
            id="why-choose-us-heading"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fffdfa] tracking-tight"
          >
            Why Choose SKB Family Restaurant
          </h2>
          <p className="mt-4 text-stone-400 text-sm sm:text-base max-w-xl mx-auto">
            Experience our commitment to good food, welcoming hospitality, and joyful family moments
            in Angara, Ranchi.
          </p>
        </motion.div>

        {/* 4 Feature Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={feature.id}
                id={feature.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                whileHover={{ y: -6 }}
                className="group relative p-7 rounded-2xl bg-gradient-to-b from-[#1c1916] to-[#161311] border border-stone-800/80 hover:border-amber-500/50 shadow-lg shadow-black/50 hover:shadow-amber-950/30 transition-all duration-300 flex flex-col justify-between"
              >
                {/* Glow accent in background on hover */}
                <div className="absolute inset-0 rounded-2xl bg-amber-500/0 group-hover:bg-amber-500/[0.02] transition-colors pointer-events-none" />

                <div>
                  {/* Icon & Badge */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="w-13 h-13 w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center group-hover:scale-110 group-hover:bg-amber-500/20 group-hover:border-amber-400/40 transition-all duration-300">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-medium text-stone-400 bg-stone-900/80 px-2.5 py-1 rounded-full border border-stone-800">
                      {feature.badge}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="font-serif text-xl font-bold text-stone-100 group-hover:text-amber-200 transition-colors mb-3">
                    {feature.title}
                  </h3>

                  {/* Description */}
                  <p className="text-stone-400 text-sm leading-relaxed">
                    {feature.description}
                  </p>
                </div>

                {/* Subtle card bottom accent line */}
                <div className="w-full h-0.5 bg-stone-800 group-hover:bg-amber-500/40 mt-6 rounded-full transition-colors" />
              </motion.div>
            );
          })}
        </div>
      </div>
    </motion.section>
  );
}
