'use client';

import { ReactNode } from 'react';
import { motion, useReducedMotion } from 'motion/react';

interface AnimatedSectionProps {
  children: ReactNode;
  id?: string;
  className?: string;
  delay?: number;
  direction?: 'up' | 'none';
}

export default function AnimatedSection({
  children,
  id,
  className = '',
  delay = 0,
  direction = 'up',
}: AnimatedSectionProps) {
  const shouldReduceMotion = useReducedMotion();

  const initialY = shouldReduceMotion || direction === 'none' ? 0 : 36;

  return (
    <motion.section
      id={id}
      initial={{
        opacity: 0,
        y: initialY,
      }}
      whileInView={{
        opacity: 1,
        y: 0,
      }}
      viewport={{
        once: true,
        amount: 0.15,
        margin: '0px 0px -60px 0px',
      }}
      transition={{
        duration: shouldReduceMotion ? 0.3 : 0.7,
        delay,
        ease: [0.22, 1, 0.36, 1],
      }}
      className={className}
    >
      {children}
    </motion.section>
  );
}
