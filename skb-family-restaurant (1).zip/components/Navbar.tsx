'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Phone, Menu as MenuIcon, X, MapPin, UtensilsCrossed } from 'lucide-react';

interface NavbarProps {
  phone: string;
}

export default function Navbar({ phone }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#hero' },
    { name: 'About', href: '#about' },
    { name: 'Why Us', href: '#why-us' },
    { name: 'Menu', href: '#menu' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'FAQ', href: '#faq' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <>
      <header
        id="main-navigation"
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isScrolled
            ? 'bg-[#151311]/95 backdrop-blur-md py-3 shadow-lg shadow-black/40 border-b border-[#3d2e22]/50'
            : 'bg-gradient-to-b from-[#121110]/90 via-[#121110]/50 to-transparent py-5'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            {/* Logo / Brand */}
            <Link
              href="#hero"
              className="group flex items-center gap-3 transition-transform duration-200 hover:scale-[1.01]"
              id="navbar-brand-logo"
            >
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#d97706] to-[#b45309] flex items-center justify-center text-white shadow-md shadow-amber-900/40 border border-amber-400/30">
                <UtensilsCrossed className="w-5 h-5 text-[#fff8ec]" />
              </div>
              <div className="flex flex-col">
                <span className="font-serif text-xl sm:text-2xl font-bold tracking-tight text-[#fdf8f0] group-hover:text-amber-300 transition-colors">
                  SKB Family Restaurant
                </span>
                <span className="text-[11px] font-medium text-amber-200/80 tracking-widest uppercase flex items-center gap-1">
                  <MapPin className="w-2.5 h-2.5 text-amber-400" /> Angara, Ranchi
                </span>
              </div>
            </Link>

            {/* Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1 xl:gap-2" aria-label="Main Navigation">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  id={`nav-link-${link.name.toLowerCase().replace(/\s+/g, '-')}`}
                  className="px-3.5 py-2 rounded-lg text-sm font-medium text-[#e6ded5] hover:text-amber-300 hover:bg-white/5 transition-all duration-150"
                >
                  {link.name}
                </Link>
              ))}
            </nav>

            {/* Right Action: Call Now */}
            <div className="hidden sm:flex items-center gap-3">
              <a
                href={`tel:${phone}`}
                id="navbar-call-btn"
                className="relative inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-medium text-sm shadow-md shadow-amber-950/50 hover:shadow-amber-600/30 transition-all duration-200 active:scale-95 border border-amber-400/40"
              >
                <Phone className="w-4 h-4 animate-pulse text-amber-100" />
                <span>Call Now</span>
              </a>
            </div>

            {/* Mobile Hamburger Button */}
            <div className="flex items-center gap-2 lg:hidden">
              <a
                href={`tel:${phone}`}
                id="navbar-mobile-call-icon"
                className="sm:hidden p-2 rounded-full bg-amber-600/20 text-amber-300 border border-amber-500/30"
                aria-label="Call SKB Family Restaurant"
              >
                <Phone className="w-4 h-4" />
              </a>
              <button
                id="mobile-menu-toggle-btn"
                type="button"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2.5 rounded-lg text-[#e6ded5] hover:text-white hover:bg-white/10 transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500"
                aria-expanded={isMobileMenuOpen}
                aria-label="Toggle menu"
              >
                {isMobileMenuOpen ? <X className="w-6 h-6 text-amber-400" /> : <MenuIcon className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu Drawer */}
      {isMobileMenuOpen && (
        <div
          id="mobile-nav-drawer"
          className="fixed inset-0 z-40 lg:hidden bg-black/80 backdrop-blur-xl pt-24 px-6 pb-8 flex flex-col justify-between"
        >
          <div className="space-y-2">
            <div className="pb-4 border-b border-white/10 mb-4">
              <div className="font-serif text-lg font-bold text-amber-300">SKB Family Restaurant</div>
              <p className="text-xs text-stone-400">Angara, Ranchi, Jharkhand</p>
            </div>

            <nav className="flex flex-col space-y-1">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="px-4 py-3 rounded-xl text-base font-medium text-stone-200 hover:text-amber-300 hover:bg-white/5 active:bg-white/10 transition-colors flex items-center justify-between"
                >
                  <span>{link.name}</span>
                  <span className="text-stone-500 text-xs">→</span>
                </Link>
              ))}
            </nav>
          </div>

          <div className="pt-6 border-t border-white/10 space-y-3">
            <a
              href={`tel:${phone}`}
              id="mobile-drawer-call-btn"
              onClick={() => setIsMobileMenuOpen(false)}
              className="w-full flex items-center justify-center gap-2 py-3.5 px-4 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 text-white font-semibold text-base shadow-lg shadow-amber-950/60"
            >
              <Phone className="w-5 h-5 text-amber-100" />
              <span>Call Now ({phone})</span>
            </a>
            <a
              href="https://wa.me/919798832616"
              target="_blank"
              rel="noopener noreferrer"
              id="mobile-drawer-whatsapp-btn"
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-700/30 text-emerald-300 border border-emerald-500/30 text-sm font-medium"
            >
              <span>Chat on WhatsApp</span>
            </a>
          </div>
        </div>
      )}
    </>
  );
}
