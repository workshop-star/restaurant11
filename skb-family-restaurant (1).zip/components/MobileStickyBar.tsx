'use client';

import { Phone, MessageSquare, Navigation } from 'lucide-react';

interface MobileStickyBarProps {
  phone: string;
  mapsUrl: string;
}

export default function MobileStickyBar({ phone, mapsUrl }: MobileStickyBarProps) {
  return (
    <aside
      id="mobile-bottom-quick-bar"
      aria-label="Quick Actions"
      className="fixed bottom-0 left-0 right-0 z-40 sm:hidden bg-[#151210]/95 backdrop-blur-lg border-t border-stone-800 px-3 py-2.5 pb-[max(0.625rem,env(safe-area-inset-bottom))] shadow-2xl shadow-black"
    >
      <div className="grid grid-cols-3 gap-2">
        <a
          href={`tel:${phone}`}
          id="mobile-bar-call"
          className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-amber-600 text-white text-[11px] font-semibold active:scale-95 transition-transform"
        >
          <Phone className="w-4 h-4 mb-0.5 text-amber-100" />
          <span>Call Now</span>
        </a>

        <a
          href="https://wa.me/919798832616"
          target="_blank"
          rel="noopener noreferrer"
          id="mobile-bar-whatsapp"
          className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-emerald-700 text-white text-[11px] font-semibold active:scale-95 transition-transform"
        >
          <MessageSquare className="w-4 h-4 mb-0.5 text-emerald-100" />
          <span>WhatsApp</span>
        </a>

        <a
          href={mapsUrl}
          target="_blank"
          rel="noopener noreferrer"
          id="mobile-bar-directions"
          className="flex flex-col items-center justify-center py-2 px-1 rounded-xl bg-[#26201a] text-stone-200 border border-stone-700 text-[11px] font-medium active:scale-95 transition-transform"
        >
          <Navigation className="w-4 h-4 mb-0.5 text-amber-400" />
          <span>Directions</span>
        </a>
      </div>
    </aside>
  );
}
