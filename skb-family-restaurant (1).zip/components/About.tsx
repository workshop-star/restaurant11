'use client';

import Image from 'next/image';
import { Sparkles, Users, Utensils, HeartHandshake, MapPin } from 'lucide-react';
import { motion } from 'motion/react';

export default function About() {
  return (
    <motion.section
      id="about"
      initial={{ opacity: 0, y: 35 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15, margin: '0px 0px -50px 0px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="py-20 lg:py-28 bg-[#151311] relative overflow-hidden"
    >
      {/* Subtle ambient lighting */}
      <div className="absolute top-1/4 left-0 w-96 h-96 bg-amber-600/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-0 w-96 h-96 bg-orange-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          {/* Left Column: Visual Composition */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-6 relative"
          >
            <div className="relative mx-auto max-w-md lg:max-w-none">
              {/* Primary Image */}
              <div className="relative h-80 sm:h-96 rounded-2xl overflow-hidden shadow-2xl shadow-black/80 border border-stone-800/80 group">
                <Image
                  src="https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80"
                  alt="SKB Family Restaurant warm dining space in Angara"
                  fill
                  sizes="(max-width: 1024px) 100vw, 50vw"
                  className="object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-amber-200/90 font-medium">
                  <span className="flex items-center gap-1.5 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-amber-500/30">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" /> Angara, Ranchi
                  </span>
                  <span className="bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-full border border-stone-700">
                    Family Seating
                  </span>
                </div>
              </div>

              {/* Secondary Overlapping Card */}
              <div className="hidden sm:block absolute -bottom-8 -right-6 w-3/5 h-48 rounded-xl overflow-hidden shadow-2xl border-2 border-stone-700/60 bg-stone-900 group">
                <Image
                  src="https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80"
                  alt="Delicious food and dining experience"
                  fill
                  sizes="30vw"
                  className="object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent" />
                <div className="absolute bottom-3 left-3 text-xs font-serif text-white font-semibold">
                  Fresh Flavors & Quality
                </div>
              </div>

              {/* Experience Accent Badge */}
              <div className="absolute -top-4 -left-4 bg-[#231d17] border border-amber-500/40 p-4 rounded-xl shadow-xl flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <HeartHandshake className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-white">Welcoming Dining</div>
                  <div className="text-xs text-stone-400">For Family & Friends</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right Column: Warm Safe Descriptive Copy */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-6 space-y-6"
          >
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold tracking-wider uppercase mb-3">
                <Sparkles className="w-3.5 h-3.5" />
                About Our Restaurant
              </div>
              <h2
                id="about-heading"
                className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fffbf2] tracking-tight leading-tight"
              >
                Welcome to <br />
                <span className="text-amber-400">SKB Family Restaurant</span>
              </h2>
            </div>

            <p className="text-stone-300 text-base sm:text-lg leading-relaxed">
              Located in Angara, Ranchi, SKB Family Restaurant offers a warm, hospitable dining
              setting crafted for families, friends, and travelers seeking delicious food in a
              comfortable environment.
            </p>

            <p className="text-stone-400 text-sm sm:text-base leading-relaxed">
              We take pride in preparing appetizing dishes with care, ensuring that every visit
              is filled with pleasant flavors and happy memories. Our dining space provides a
              relaxing ambiance where you can comfortably enjoy quality time with the people who
              matter most.
            </p>

            {/* Core Values / Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-stone-800">
              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-stone-900/60 border border-stone-800/80">
                <div className="p-2 rounded-lg bg-amber-500/15 text-amber-400 flex-shrink-0 mt-0.5">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-stone-200">Family & Friends</h3>
                  <p className="text-xs text-stone-400 mt-0.5">
                    Thoughtfully arranged seating perfect for get-togethers and group meals.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3.5 rounded-xl bg-stone-900/60 border border-stone-800/80">
                <div className="p-2 rounded-lg bg-amber-500/15 text-amber-400 flex-shrink-0 mt-0.5">
                  <Utensils className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-stone-200">Delicious Taste</h3>
                  <p className="text-xs text-stone-400 mt-0.5">
                    Hearty, satisfying meals prepared with dedication to authentic flavor.
                  </p>
                </div>
              </div>
            </div>

            {/* Quick Action */}
            <div className="pt-2">
              <a
                href="#menu"
                id="about-explore-menu-btn"
                className="inline-flex items-center gap-2 text-sm font-medium text-amber-300 hover:text-amber-200 hover:underline underline-offset-4 transition-colors"
              >
                <span>Explore our menu categories</span>
                <span>→</span>
              </a>
            </div>
          </motion.div>
        </div>
      </div>
    </motion.section>
  );
}
