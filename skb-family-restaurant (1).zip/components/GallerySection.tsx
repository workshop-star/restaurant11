'use client';

import { useState } from 'react';
import Image from 'next/image';
import { Camera, Eye, X, ChevronLeft, ChevronRight, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface GalleryItem {
  id: string;
  src: string;
  alt: string;
  category: string;
  caption: string;
}

export default function GallerySection() {
  const [selectedImageIndex, setSelectedImageIndex] = useState<number | null>(null);

  // Demo restaurant & food photography (easily replaceable with restaurant's real photos)
  const galleryItems: GalleryItem[] = [
    {
      id: 'gallery-1',
      src: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?auto=format&fit=crop&w=1200&q=80',
      alt: 'Family dining seating arrangement demo',
      category: 'Dining Space',
      caption: 'Warm, comfortable seating area designed for family get-togethers',
    },
    {
      id: 'gallery-2',
      src: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80',
      alt: 'Freshly prepared appetizing dish presentation demo',
      category: 'Delicious Food',
      caption: 'Flavorful culinary creations prepared with quality ingredients',
    },
    {
      id: 'gallery-3',
      src: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1200&q=80',
      alt: 'Restaurant evening ambient lighting demo',
      category: 'Ambience',
      caption: 'Relaxed and inviting evening atmosphere for pleasant conversations',
    },
    {
      id: 'gallery-4',
      src: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=1200&q=80',
      alt: 'Family feast meal spread demo',
      category: 'Food Spread',
      caption: 'Hearty dining platters suited for table sharing among friends and family',
    },
    {
      id: 'gallery-5',
      src: 'https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&w=1200&q=80',
      alt: 'Cozy dining interior and hospitality demo',
      category: 'Dining Space',
      caption: 'Hygienic and attentive dining atmosphere in Angara, Ranchi',
    },
    {
      id: 'gallery-6',
      src: 'https://images.unsplash.com/photo-1559339352-11d035aa65de?auto=format&fit=crop&w=1200&q=80',
      alt: 'Refreshing table beverages demo',
      category: 'Beverages',
      caption: 'Cooling beverages and refreshments to complement your meal',
    },
  ];

  const handleOpenLightbox = (index: number) => {
    setSelectedImageIndex(index);
  };

  const handleCloseLightbox = () => {
    setSelectedImageIndex(null);
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedImageIndex !== null) {
      setSelectedImageIndex((selectedImageIndex - 1 + galleryItems.length) % galleryItems.length);
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (selectedImageIndex !== null) {
      setSelectedImageIndex((selectedImageIndex + 1) % galleryItems.length);
    }
  };

  return (
    <motion.section
      id="gallery"
      initial={{ opacity: 0, y: 35 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15, margin: '0px 0px -50px 0px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="py-20 lg:py-28 bg-[#121110] relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold tracking-wider uppercase mb-3">
            <Camera className="w-3.5 h-3.5" />
            Visual Experience
          </div>
          <h2
            id="gallery-heading"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fffdfa] tracking-tight"
          >
            Restaurant Gallery
          </h2>
          <p className="mt-4 text-stone-400 text-sm sm:text-base max-w-xl mx-auto">
            A glimpse into the cozy dining ambiance and appetizing culinary moments at SKB Family Restaurant.
          </p>

          {/* Transparent Stock / Demo Photo Note */}
          <div className="mt-4 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-lg bg-stone-900 border border-stone-800 text-stone-400 text-xs">
            <Info className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
            <span>
              Demonstration photography displayed. Real photos of SKB Family Restaurant can be directly added.
            </span>
          </div>
        </motion.div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, scale: 0.96 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.4, delay: index * 0.08 }}
              onClick={() => handleOpenLightbox(index)}
              className="group relative h-64 sm:h-72 rounded-2xl overflow-hidden cursor-pointer bg-stone-900 border border-stone-800 hover:border-amber-500/50 shadow-lg shadow-black/40 transition-all duration-300"
            >
              <Image
                src={item.src}
                alt={item.alt}
                fill
                sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                className="object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />

              {/* Hover Overlay Content */}
              <div className="absolute inset-0 p-5 flex flex-col justify-between">
                <div className="self-end opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                  <div className="p-2 rounded-full bg-black/60 backdrop-blur-md text-amber-300 border border-amber-500/30">
                    <Eye className="w-4 h-4" />
                  </div>
                </div>

                <div>
                  <span className="text-[11px] font-medium text-amber-300 bg-amber-950/80 px-2.5 py-0.5 rounded-full border border-amber-500/30 inline-block mb-1.5">
                    {item.category}
                  </span>
                  <p className="text-white text-sm font-medium line-clamp-1">
                    {item.caption}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {selectedImageIndex !== null && (
          <div
            id="gallery-lightbox"
            onClick={handleCloseLightbox}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-8 bg-black/95 backdrop-blur-md"
          >
            {/* Close Button */}
            <button
              type="button"
              id="lightbox-close-btn"
              onClick={handleCloseLightbox}
              className="absolute top-5 right-5 z-10 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              aria-label="Close photo preview"
            >
              <X className="w-6 h-6" />
            </button>

            {/* Prev Button */}
            <button
              type="button"
              id="lightbox-prev-btn"
              onClick={handlePrev}
              className="absolute left-4 sm:left-8 z-10 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              aria-label="Previous photo"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            {/* Next Button */}
            <button
              type="button"
              id="lightbox-next-btn"
              onClick={handleNext}
              className="absolute right-4 sm:right-8 z-10 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
              aria-label="Next photo"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Active Image Container */}
            <div
              className="relative max-w-4xl w-full max-h-[80vh] aspect-video rounded-2xl overflow-hidden shadow-2xl border border-stone-800"
              onClick={(e) => e.stopPropagation()}
            >
              <Image
                src={galleryItems[selectedImageIndex].src}
                alt={galleryItems[selectedImageIndex].alt}
                fill
                priority
                sizes="90vw"
                className="object-contain bg-black"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black via-black/80 to-transparent text-center">
                <span className="text-xs font-semibold text-amber-300 block mb-1">
                  {galleryItems[selectedImageIndex].category} ({selectedImageIndex + 1} of {galleryItems.length})
                </span>
                <p className="text-sm text-stone-200">
                  {galleryItems[selectedImageIndex].caption}
                </p>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </motion.section>
  );
}
