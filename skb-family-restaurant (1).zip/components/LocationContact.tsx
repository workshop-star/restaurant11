'use client';

import { useState } from 'react';
import { MapPin, Phone, MessageSquare, Navigation, Clock, Send, Check } from 'lucide-react';
import { motion } from 'motion/react';

interface LocationContactProps {
  phone: string;
  mapsUrl: string;
}

export default function LocationContact({ phone, mapsUrl }: LocationContactProps) {
  const [formData, setFormData] = useState({
    name: '',
    guestCount: '2-4 Guests',
    preferredTime: 'Lunch / Afternoon',
    notes: '',
  });
  const [isCopied, setIsCopied] = useState(false);

  const handleWhatsAppInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    const text = `Hello SKB Family Restaurant, I would like to inquire about visiting your restaurant in Angara, Ranchi.%0A%0A*Name:* ${encodeURIComponent(formData.name || 'Guest')}%0A*Party Size:* ${encodeURIComponent(formData.guestCount)}%0A*Preferred Dining Time:* ${encodeURIComponent(formData.preferredTime)}${formData.notes ? `%0A*Notes:* ${encodeURIComponent(formData.notes)}` : ''}`;
    window.open(`https://wa.me/919798832616?text=${text}`, '_blank');
  };

  const handleCopyAddress = () => {
    navigator.clipboard.writeText('SKB Family Restaurant, Angara, Ranchi, Jharkhand, India');
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  return (
    <motion.section
      id="contact"
      initial={{ opacity: 0, y: 35 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15, margin: '0px 0px -50px 0px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="py-20 lg:py-28 bg-[#121110] relative"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold tracking-wider uppercase mb-3">
            <MapPin className="w-3.5 h-3.5" />
            Visit & Contact
          </div>
          <h2
            id="contact-heading"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fffdfa] tracking-tight"
          >
            Location & Contact
          </h2>
          <p className="mt-4 text-stone-300 text-sm sm:text-base max-w-xl mx-auto">
            Conveniently situated in Angara, Ranchi. Reach out via phone or WhatsApp, or get instant navigation directions.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Left Column: Business Details & 3 Primary CTAs */}
          <div className="lg:col-span-6 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="p-8 rounded-3xl bg-gradient-to-br from-[#1d1916] to-[#151210] border border-stone-800 shadow-xl"
            >
              <div className="border-b border-stone-800 pb-6 mb-6">
                <h3 className="font-serif text-2xl font-bold text-white mb-2">
                  SKB Family Restaurant
                </h3>
                <p className="text-amber-300 text-sm font-medium flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  Angara, Ranchi, Jharkhand, India
                </p>
              </div>

              {/* Address & Phone Details */}
              <div className="space-y-4 mb-8">
                <div className="flex items-start gap-4 p-4 rounded-xl bg-stone-900/70 border border-stone-800">
                  <div className="p-2.5 rounded-lg bg-amber-500/15 text-amber-400 flex-shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="text-xs font-medium text-stone-400">Postal Address</div>
                    <div className="text-sm font-semibold text-stone-200 mt-0.5">
                      Angara, Ranchi, Jharkhand, India
                    </div>
                    <button
                      type="button"
                      onClick={handleCopyAddress}
                      className="text-xs text-amber-400 hover:text-amber-300 mt-1 inline-flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      {isCopied ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Address Copied</span>
                        </>
                      ) : (
                        'Copy Address'
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex items-start gap-4 p-4 rounded-xl bg-stone-900/70 border border-stone-800">
                  <div className="p-2.5 rounded-lg bg-amber-500/15 text-amber-400 flex-shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-medium text-stone-400">Direct Telephone</div>
                    <div className="text-base font-semibold text-stone-100 mt-0.5 font-mono">
                      {phone}
                    </div>
                    <div className="text-xs text-stone-400 mt-0.5">
                      Call directly for inquiries, directions, or party meals
                    </div>
                  </div>
                </div>
              </div>

              {/* 3 Prominent Required Action Buttons */}
              <div className="space-y-3">
                <div className="text-xs font-bold uppercase tracking-wider text-stone-400 mb-2">
                  Direct Actions
                </div>

                {/* 1. Call Now */}
                <a
                  href={`tel:${phone}`}
                  id="contact-call-btn"
                  className="w-full flex items-center justify-center gap-3 py-3.5 px-6 rounded-xl bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white font-semibold text-base shadow-lg shadow-amber-950/60 transition-all duration-200 active:scale-98 border border-amber-400/30"
                >
                  <Phone className="w-5 h-5 text-amber-100" />
                  <span>Call Now ({phone})</span>
                </a>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {/* 2. WhatsApp */}
                  <a
                    href="https://wa.me/919798832616"
                    target="_blank"
                    rel="noopener noreferrer"
                    id="contact-whatsapp-btn"
                    className="flex items-center justify-center gap-2.5 py-3 px-5 rounded-xl bg-emerald-700/80 hover:bg-emerald-600 text-white font-semibold text-sm shadow-md transition-all duration-200 active:scale-98 border border-emerald-500/40"
                  >
                    <MessageSquare className="w-4 h-4 text-emerald-200" />
                    <span>WhatsApp</span>
                  </a>

                  {/* 3. Get Directions */}
                  <a
                    href={mapsUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    id="contact-directions-btn"
                    className="flex items-center justify-center gap-2.5 py-3 px-5 rounded-xl bg-[#2b241e] hover:bg-[#382f27] text-stone-100 font-semibold text-sm border border-stone-700 hover:border-amber-400/50 shadow-md transition-all duration-200 active:scale-98"
                  >
                    <Navigation className="w-4 h-4 text-amber-400" />
                    <span>Get Directions</span>
                  </a>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Right Column: Google Maps Area & Quick WhatsApp Table Inquiry */}
          <div className="lg:col-span-6 space-y-6">
            {/* Map Area / Embed Placeholder */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="p-6 rounded-3xl bg-[#1a1613] border border-stone-800 shadow-xl overflow-hidden"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-xs font-semibold text-stone-200 uppercase tracking-wider">
                    Interactive Map Area
                  </span>
                </div>
                <a
                  href={mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-amber-300 hover:text-amber-200 font-medium inline-flex items-center gap-1"
                >
                  Open in Google Maps ↗
                </a>
              </div>

              {/* Map Placeholder Graphic / Google Search Embed Frame */}
              <div className="relative h-64 sm:h-72 w-full rounded-2xl overflow-hidden border border-stone-800 bg-[#241f1a] flex flex-col items-center justify-center text-center p-6 group">
                <div className="w-14 h-14 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                  <MapPin className="w-7 h-7" />
                </div>
                <div className="font-serif text-lg font-bold text-white mb-1">
                  SKB Family Restaurant
                </div>
                <div className="text-xs text-stone-400 max-w-sm mb-4">
                  Angara, Ranchi, Jharkhand, India
                </div>
                <a
                  href={mapsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-amber-600 hover:bg-amber-500 text-white text-xs font-semibold shadow-md transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>Navigate on Google Maps</span>
                </a>

                {/* Subtext for easy future embed replacement */}
                <span className="absolute bottom-2 text-[10px] text-stone-400">
                  Ready for restaurant Google Maps embed iframe or live search view
                </span>
              </div>
            </motion.div>

            {/* Quick Dining / Visit Inquiry Form via WhatsApp */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="p-6 rounded-3xl bg-[#1a1613] border border-stone-800 shadow-xl"
            >
              <div className="flex items-center gap-2 mb-3">
                <Clock className="w-4 h-4 text-amber-400" />
                <h4 className="text-sm font-bold text-white uppercase tracking-wider">
                  Planning a Visit? Send Quick Inquiry
                </h4>
              </div>
              <p className="text-xs text-stone-400 mb-4">
                Let us know your party size to quickly reach out on WhatsApp.
              </p>

              <form onSubmit={handleWhatsAppInquiry} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="inquiry-name" className="block text-[11px] font-medium text-stone-400 mb-1">
                      Your Name
                    </label>
                    <input
                      id="inquiry-name"
                      type="text"
                      placeholder="e.g. Rahul Kumar"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-none focus:border-amber-500 transition-colors"
                    />
                  </div>

                  <div>
                    <label htmlFor="inquiry-count" className="block text-[11px] font-medium text-stone-400 mb-1">
                      Party Size
                    </label>
                    <select
                      id="inquiry-count"
                      value={formData.guestCount}
                      onChange={(e) => setFormData({ ...formData, guestCount: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl bg-stone-900 border border-stone-800 text-stone-200 text-xs focus:outline-none focus:border-amber-500 transition-colors"
                    >
                      <option value="1-2 Guests">1 - 2 Guests</option>
                      <option value="3-5 Guests">3 - 5 Guests (Family)</option>
                      <option value="6-10 Guests">6 - 10 Guests (Large Group)</option>
                      <option value="10+ Guests">10+ Guests (Celebration)</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  id="inquiry-submit-btn"
                  className="w-full flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs transition-colors cursor-pointer"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>Send Details via WhatsApp</span>
                </button>
              </form>
            </motion.div>
          </div>
        </div>
      </div>
    </motion.section>
  );
}
