'use client';

import Link from 'next/link';
import { Phone, MessageSquare, MapPin, UtensilsCrossed } from 'lucide-react';
import { motion } from 'motion/react';

interface FooterProps {
  phone: string;
  mapsUrl: string;
}

export default function Footer({ phone, mapsUrl }: FooterProps) {
  const currentYear = new Date().getFullYear();

  const navLinks = [
    { name: 'Home', href: '#hero' },
    { name: 'About', href: '#about' },
    { name: 'Why Us', href: '#why-us' },
    { name: 'Menu', href: '#menu' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Reviews', href: '#reviews' },
    { name: 'FAQ', href: '#faq' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <motion.footer
      id="footer"
      initial={{ opacity: 0, y: 25 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.1 }}
      transition={{ duration: 0.6, ease: 'easeOut' }}
      className="bg-[#0e0c0b] text-stone-400 border-t border-stone-800/80 pt-16 pb-12"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 lg:gap-8 pb-12 border-b border-stone-800/60">
          {/* Col 1: Brand & Tagline */}
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#d97706] to-[#b45309] flex items-center justify-center text-white border border-amber-400/30">
                <UtensilsCrossed className="w-5 h-5 text-[#fff8ec]" />
              </div>
              <span className="font-serif text-2xl font-bold text-white tracking-tight">
                SKB Family Restaurant
              </span>
            </div>
            <p className="text-stone-400 text-sm max-w-sm leading-relaxed">
              &ldquo;Good Food. Great Taste. Happy Moments.&rdquo;
              <br />
              A welcoming dining destination crafted for family, friends, and shared culinary experiences in Angara, Ranchi.
            </p>

            <div className="flex items-center gap-3 pt-2">
              {/* Call Icon Link */}
              <a
                href={`tel:${phone}`}
                id="footer-call-link"
                className="p-3 rounded-full bg-stone-900 border border-stone-800 text-amber-400 hover:text-white hover:bg-amber-600 transition-colors"
                aria-label={`Call ${phone}`}
                title="Call SKB Family Restaurant"
              >
                <Phone className="w-4 h-4" />
              </a>

              {/* WhatsApp Icon Link */}
              <a
                href="https://wa.me/919798832616"
                target="_blank"
                rel="noopener noreferrer"
                id="footer-whatsapp-link"
                className="p-3 rounded-full bg-stone-900 border border-stone-800 text-emerald-400 hover:text-white hover:bg-emerald-600 transition-colors"
                aria-label="Chat on WhatsApp"
                title="WhatsApp SKB Family Restaurant"
              >
                <MessageSquare className="w-4 h-4" />
              </a>

              {/* Location Icon Link */}
              <a
                href={mapsUrl}
                target="_blank"
                rel="noopener noreferrer"
                id="footer-location-link"
                className="p-3 rounded-full bg-stone-900 border border-stone-800 text-amber-400 hover:text-white hover:bg-amber-600 transition-colors"
                aria-label="View Location on Google Maps"
                title="Location on Google Maps"
              >
                <MapPin className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300">
              Quick Navigation
            </h4>
            <ul className="space-y-2 text-sm">
              {navLinks.map((link) => (
                <li key={link.name}>
                  <Link
                    href={link.href}
                    className="hover:text-amber-300 transition-colors inline-block py-0.5"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3: Direct Details */}
          <div className="lg:col-span-4 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-amber-300">
              Restaurant Details
            </h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                <div>
                  <div className="text-stone-200 font-medium">SKB Family Restaurant</div>
                  <div className="text-stone-400 text-xs">Angara, Ranchi, Jharkhand, India</div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-amber-400 flex-shrink-0" />
                <a
                  href={`tel:${phone}`}
                  className="text-stone-200 hover:text-amber-300 transition-colors font-mono"
                >
                  {phone}
                </a>
              </div>

              <div className="pt-2 text-xs text-stone-500">
                Average Rating: 4.5 / 5 ★ (46 Customer Reviews)
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-stone-400 gap-4">
          <p>© {currentYear} SKB Family Restaurant. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Angara, Ranchi, Jharkhand
          </p>
        </div>
      </div>
    </motion.footer>
  );
}
