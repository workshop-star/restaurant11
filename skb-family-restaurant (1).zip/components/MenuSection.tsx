'use client';

import { useState } from 'react';
import { Utensils, Sparkles, HelpCircle, Phone, X, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface MenuSectionProps {
  phone: string;
}

interface CategoryPlaceholder {
  id: string;
  name: string;
  description: string;
  items: {
    title: string;
    description: string;
    tag: string;
  }[];
}

export default function MenuSection({ phone }: MenuSectionProps) {
  const [activeCategory, setActiveCategory] = useState('starters');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Clearly marked placeholder/demo categories strictly adhering to user instructions:
  // DO NOT invent real menu items or prices.
  const categories: CategoryPlaceholder[] = [
    {
      id: 'starters',
      name: 'Starters',
      description: 'Appetizing appetizers & crisp finger foods to begin your family meal',
      items: [
        {
          title: 'Starter Selection 01',
          description: 'Customizable starter dish slot — ideal for vegetarian or non-vegetarian appetizers.',
          tag: 'Demo Starter Slot',
        },
        {
          title: 'Starter Selection 02',
          description: 'Savory starter slot — customize with your popular fried or roasted appetizer.',
          tag: 'Demo Starter Slot',
        },
        {
          title: 'Starter Selection 03',
          description: 'Crispy platter slot — customize with seasoned snacks for group sharing.',
          tag: 'Demo Starter Slot',
        },
        {
          title: 'Starter Selection 04',
          description: 'Fresh seasonal starter slot — customize with house specialty appetizers.',
          tag: 'Demo Starter Slot',
        },
      ],
    },
    {
      id: 'main-course',
      name: 'Main Course',
      description: 'Hearty gravies, wholesome curries, breads & aromatic rice preparations',
      items: [
        {
          title: 'Main Course Dish 01',
          description: 'Rich gravy preparation slot — customize with your signature curry dish.',
          tag: 'Demo Main Course',
        },
        {
          title: 'Main Course Dish 02',
          description: 'Traditional spiced curry slot — customize with regional or classic recipes.',
          tag: 'Demo Main Course',
        },
        {
          title: 'Rice / Biryani Special',
          description: 'Steamed or seasoned rice preparation slot — customize with aromatic rice dishes.',
          tag: 'Demo Rice Slot',
        },
        {
          title: 'Breads & Accompaniments',
          description: 'Freshly baked tandoori or tava breads and accompaniments slot.',
          tag: 'Demo Bread Slot',
        },
      ],
    },
    {
      id: 'family-specials',
      name: 'Family Specials',
      description: 'Generous combination platters and feast portions suited for group dining',
      items: [
        {
          title: 'Family Sharing Platter A',
          description: 'Multi-dish combination platter slot — perfect for tables of 3 to 4 guests.',
          tag: 'Demo Family Platter',
        },
        {
          title: 'Family Sharing Platter B',
          description: 'Hearty festive feast slot — customizable for celebrations and family lunches.',
          tag: 'Demo Family Platter',
        },
        {
          title: 'Weekend Group Feast',
          description: 'Curated combination of starters, curries, and sides for gatherings.',
          tag: 'Demo Feast Slot',
        },
      ],
    },
    {
      id: 'beverages',
      name: 'Beverages',
      description: 'Cooling refreshments, hot brews & traditional beverages',
      items: [
        {
          title: 'Refreshing Coolers',
          description: 'Chilled soft beverage or traditional cooler slot — customize with cold drinks.',
          tag: 'Demo Beverage',
        },
        {
          title: 'Hot Beverage Selection',
          description: 'Steaming tea or coffee slot — customize with your fresh hot beverage options.',
          tag: 'Demo Hot Beverage',
        },
        {
          title: 'Sweet & Salty Refreshers',
          description: 'Traditional chilled churned beverage or mocktail placeholder.',
          tag: 'Demo Refreshment',
        },
      ],
    },
    {
      id: 'chefs-specials',
      name: "Chef's Specials",
      description: 'Signature culinary recommendations crafted for memorable dining',
      items: [
        {
          title: "Chef's Signature Recommendation",
          description: "Exclusive house specialty preparation slot — highlight your best-selling recipe.",
          tag: "Demo Chef's Special",
        },
        {
          title: 'Seasonal Daily Special',
          description: 'Rotational seasonal dish slot — customizable based on market-fresh produce.',
          tag: 'Demo Daily Special',
        },
        {
          title: 'Celebration Sizzler Slot',
          description: 'Signature hot-plate preparation slot — customize with special sizzler dishes.',
          tag: 'Demo Specialty',
        },
      ],
    },
  ];

  const currentCategory = categories.find((c) => c.id === activeCategory) || categories[0];

  return (
    <motion.section
      id="menu"
      initial={{ opacity: 0, y: 35 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.15, margin: '0px 0px -50px 0px' }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
      className="py-20 lg:py-28 bg-[#151311] relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto mb-12"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold tracking-wider uppercase mb-3">
            <Utensils className="w-3.5 h-3.5" />
            Culinary Offerings
          </div>
          <h2
            id="menu-section-heading"
            className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-[#fffdfa] tracking-tight"
          >
            Menu Preview
          </h2>
          <p className="mt-4 text-stone-300 text-sm sm:text-base max-w-2xl mx-auto">
            Explore our curated culinary categories below.
          </p>

          {/* Transparent Notice for Visitors and Owner */}
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs">
            <Info className="w-4 h-4 flex-shrink-0 text-amber-400" />
            <span>
              <strong>Note for diners:</strong> Full printed menu with exact seasonal items and daily pricing is available on-site in Angara.
            </span>
          </div>
        </motion.div>

        {/* Category Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-2 sm:gap-3 mb-10">
          {categories.map((category) => {
            const isActive = category.id === activeCategory;
            return (
              <button
                key={category.id}
                id={`menu-tab-${category.id}`}
                type="button"
                onClick={() => setActiveCategory(category.id)}
                className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-semibold transition-all duration-200 cursor-pointer ${
                  isActive
                    ? 'bg-amber-600 text-white shadow-lg shadow-amber-950/60 border border-amber-400/50'
                    : 'bg-stone-900/80 text-stone-300 border border-stone-800 hover:border-stone-700 hover:text-white'
                }`}
              >
                {category.name}
              </button>
            );
          })}
        </div>

        {/* Category Description Banner */}
        <div className="text-center mb-8">
          <p className="text-stone-400 text-sm italic">
            &ldquo;{currentCategory.description}&rdquo;
          </p>
        </div>

        {/* Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto mb-12">
          {currentCategory.items.map((item, index) => (
            <motion.div
              key={`${currentCategory.id}-${index}`}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className="p-6 rounded-2xl bg-gradient-to-br from-[#1d1916] to-[#161311] border border-stone-800/90 hover:border-amber-500/40 transition-colors shadow-md flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-4 mb-2">
                  <h3 className="font-serif text-lg font-bold text-stone-100">
                    {item.title}
                  </h3>
                  <span className="text-[11px] font-medium text-amber-300/90 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20 whitespace-nowrap">
                    {item.tag}
                  </span>
                </div>
                <p className="text-stone-400 text-xs sm:text-sm leading-relaxed mb-4">
                  {item.description}
                </p>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-stone-800/80 text-xs text-stone-500">
                <span className="italic">Price & daily availability on request</span>
                <a
                  href={`tel:${phone}`}
                  className="text-amber-400 hover:text-amber-300 font-medium inline-flex items-center gap-1"
                >
                  <Phone className="w-3 h-3" /> Inquire
                </a>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA: View Full Menu */}
        <div className="text-center">
          <button
            type="button"
            id="view-full-menu-btn"
            onClick={() => setIsModalOpen(true)}
            className="inline-flex items-center gap-2.5 px-8 py-3.5 rounded-full bg-[#241e19] hover:bg-[#2f2720] text-amber-200 border border-amber-500/40 hover:border-amber-400 text-sm font-semibold shadow-lg shadow-black/40 transition-all duration-200 active:scale-95 cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>View Full Menu Details</span>
          </button>
        </div>
      </div>

      {/* Full Menu Modal Notice */}
      <AnimatePresence>
        {isModalOpen && (
          <div
            id="menu-info-modal"
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm"
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className="relative w-full max-w-lg p-6 sm:p-8 rounded-2xl bg-[#1b1714] border border-amber-500/40 shadow-2xl text-left"
            >
              <button
                type="button"
                id="close-menu-modal-btn"
                onClick={() => setIsModalOpen(false)}
                className="absolute top-4 right-4 p-2 text-stone-400 hover:text-white rounded-lg hover:bg-white/10"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center">
                  <Utensils className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif text-xl font-bold text-white">
                    SKB Family Restaurant Menu
                  </h4>
                  <p className="text-xs text-amber-300">Angara, Ranchi, Jharkhand</p>
                </div>
              </div>

              <div className="space-y-4 text-stone-300 text-sm leading-relaxed mb-6">
                <p>
                  Our kitchen serves fresh preparations daily spanning hearty Starters, Main Course curries,
                  Family Special platters, and cooling Beverages.
                </p>
                <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs space-y-1">
                  <div className="font-semibold">Notice for Diners & Management:</div>
                  <div>
                    The detailed physical menu with current day specials, seasonal items, and pricing
                    is presented at your table in Angara. You can also call us directly to check today&apos;s
                    menu before visiting.
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-center gap-3">
                <a
                  href={`tel:${phone}`}
                  className="w-full sm:w-auto flex-1 inline-flex items-center justify-center gap-2 py-3 px-5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-medium text-sm transition-colors"
                >
                  <Phone className="w-4 h-4" />
                  <span>Call Us ({phone})</span>
                </a>
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="w-full sm:w-auto px-5 py-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-sm font-medium transition-colors"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.section>
  );
}
